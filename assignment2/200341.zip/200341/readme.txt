Install the required libraries and tools:
1) numpy
2) scipy
3) matplotlib
4) seaborn
Run the jupyter notebook:
CS772_HW2_200341.ipynb to get the results of plot
Thanks!