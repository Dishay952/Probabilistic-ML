Requirements:
1. python3
2. jupyter notebook
3. numpy
4. matplotlib
5. scipy

Run instructions:
1. Open `Rejection Sampling.ipynb` in jupyter notebook
2. Under kernel select `Restart and Run All`
3. Open `MH Sampling.ipynb` in jupyter notebook
4. Under kernel select `Restart and Run All`